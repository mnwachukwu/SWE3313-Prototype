﻿namespace SWE_3313_Prototype
{
    partial class Tables
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            button25 = new Button();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            button29 = new Button();
            button30 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            labelName = new Label();
            buttonLogOut = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(50, 77);
            button1.Name = "button1";
            button1.Size = new Size(177, 53);
            button1.TabIndex = 0;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(50, 136);
            button2.Name = "button2";
            button2.Size = new Size(177, 53);
            button2.TabIndex = 1;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(50, 195);
            button3.Name = "button3";
            button3.Size = new Size(177, 53);
            button3.TabIndex = 2;
            button3.Text = "button3";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(50, 254);
            button4.Name = "button4";
            button4.Size = new Size(177, 53);
            button4.TabIndex = 3;
            button4.Text = "button4";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(50, 313);
            button5.Name = "button5";
            button5.Size = new Size(177, 53);
            button5.TabIndex = 4;
            button5.Text = "button5";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(50, 372);
            button6.Name = "button6";
            button6.Size = new Size(177, 53);
            button6.TabIndex = 5;
            button6.Text = "button6";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Location = new Point(281, 77);
            button7.Name = "button7";
            button7.Size = new Size(177, 53);
            button7.TabIndex = 6;
            button7.Text = "button7";
            button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(281, 136);
            button8.Name = "button8";
            button8.Size = new Size(177, 53);
            button8.TabIndex = 7;
            button8.Text = "button8";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(281, 195);
            button9.Name = "button9";
            button9.Size = new Size(177, 53);
            button9.TabIndex = 8;
            button9.Text = "button9";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(281, 254);
            button10.Name = "button10";
            button10.Size = new Size(177, 53);
            button10.TabIndex = 9;
            button10.Text = "button10";
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Location = new Point(281, 313);
            button11.Name = "button11";
            button11.Size = new Size(177, 53);
            button11.TabIndex = 10;
            button11.Text = "button11";
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(281, 372);
            button12.Name = "button12";
            button12.Size = new Size(177, 53);
            button12.TabIndex = 11;
            button12.Text = "button12";
            button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.Location = new Point(513, 77);
            button13.Name = "button13";
            button13.Size = new Size(177, 53);
            button13.TabIndex = 12;
            button13.Text = "button13";
            button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.Location = new Point(513, 136);
            button14.Name = "button14";
            button14.Size = new Size(177, 53);
            button14.TabIndex = 13;
            button14.Text = "button14";
            button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            button15.Location = new Point(513, 195);
            button15.Name = "button15";
            button15.Size = new Size(177, 53);
            button15.TabIndex = 14;
            button15.Text = "button15";
            button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            button16.Location = new Point(513, 254);
            button16.Name = "button16";
            button16.Size = new Size(177, 53);
            button16.TabIndex = 15;
            button16.Text = "button16";
            button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            button17.Location = new Point(513, 313);
            button17.Name = "button17";
            button17.Size = new Size(177, 53);
            button17.TabIndex = 16;
            button17.Text = "button17";
            button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            button18.Location = new Point(513, 372);
            button18.Name = "button18";
            button18.Size = new Size(177, 53);
            button18.TabIndex = 17;
            button18.Text = "button18";
            button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            button19.Location = new Point(746, 77);
            button19.Name = "button19";
            button19.Size = new Size(177, 53);
            button19.TabIndex = 18;
            button19.Text = "button19";
            button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            button20.Location = new Point(746, 136);
            button20.Name = "button20";
            button20.Size = new Size(177, 53);
            button20.TabIndex = 19;
            button20.Text = "button20";
            button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            button21.Location = new Point(746, 195);
            button21.Name = "button21";
            button21.Size = new Size(177, 53);
            button21.TabIndex = 20;
            button21.Text = "button21";
            button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            button22.Location = new Point(746, 254);
            button22.Name = "button22";
            button22.Size = new Size(177, 53);
            button22.TabIndex = 21;
            button22.Text = "button22";
            button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            button23.Location = new Point(746, 313);
            button23.Name = "button23";
            button23.Size = new Size(177, 53);
            button23.TabIndex = 22;
            button23.Text = "button23";
            button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            button24.Location = new Point(746, 372);
            button24.Name = "button24";
            button24.Size = new Size(177, 53);
            button24.TabIndex = 23;
            button24.Text = "button24";
            button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            button25.Location = new Point(971, 77);
            button25.Name = "button25";
            button25.Size = new Size(177, 53);
            button25.TabIndex = 24;
            button25.Text = "button25";
            button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            button26.Location = new Point(971, 136);
            button26.Name = "button26";
            button26.Size = new Size(177, 53);
            button26.TabIndex = 25;
            button26.Text = "button26";
            button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            button27.Location = new Point(971, 195);
            button27.Name = "button27";
            button27.Size = new Size(177, 53);
            button27.TabIndex = 26;
            button27.Text = "button27";
            button27.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            button28.Location = new Point(971, 254);
            button28.Name = "button28";
            button28.Size = new Size(177, 53);
            button28.TabIndex = 27;
            button28.Text = "button28";
            button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            button29.Location = new Point(971, 313);
            button29.Name = "button29";
            button29.Size = new Size(177, 53);
            button29.TabIndex = 28;
            button29.Text = "button29";
            button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            button30.Location = new Point(971, 372);
            button30.Name = "button30";
            button30.Size = new Size(177, 53);
            button30.TabIndex = 29;
            button30.Text = "button30";
            button30.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(97, 42);
            label1.Name = "label1";
            label1.Size = new Size(80, 21);
            label1.TabIndex = 30;
            label1.Text = "Section 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(331, 42);
            label2.Name = "label2";
            label2.Size = new Size(80, 21);
            label2.TabIndex = 31;
            label2.Text = "Section 2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(564, 42);
            label3.Name = "label3";
            label3.Size = new Size(80, 21);
            label3.TabIndex = 32;
            label3.Text = "Section 3";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(797, 42);
            label4.Name = "label4";
            label4.Size = new Size(80, 21);
            label4.TabIndex = 33;
            label4.Text = "Section 4";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(1020, 42);
            label5.Name = "label5";
            label5.Size = new Size(80, 21);
            label5.TabIndex = 34;
            label5.Text = "Section 5";
            // 
            // labelName
            // 
            labelName.AutoSize = true;
            labelName.Location = new Point(56, 463);
            labelName.Name = "labelName";
            labelName.Size = new Size(87, 15);
            labelName.TabIndex = 35;
            labelName.Text = "Welcome, Nick";
            // 
            // buttonLogOut
            // 
            buttonLogOut.Location = new Point(564, 459);
            buttonLogOut.Name = "buttonLogOut";
            buttonLogOut.Size = new Size(75, 23);
            buttonLogOut.TabIndex = 36;
            buttonLogOut.Text = "Logout";
            buttonLogOut.UseVisualStyleBackColor = true;
            buttonLogOut.Click += buttonLogOut_Click;
            // 
            // Tables
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1209, 508);
            Controls.Add(buttonLogOut);
            Controls.Add(labelName);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button25);
            Controls.Add(button26);
            Controls.Add(button27);
            Controls.Add(button28);
            Controls.Add(button29);
            Controls.Add(button30);
            Controls.Add(button19);
            Controls.Add(button20);
            Controls.Add(button21);
            Controls.Add(button22);
            Controls.Add(button23);
            Controls.Add(button24);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button16);
            Controls.Add(button17);
            Controls.Add(button18);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Tables";
            Text = "Tables";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button30;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label labelName;
        private Button buttonLogOut;
    }
}